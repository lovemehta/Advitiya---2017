<?php
$con = mysqli_connect("localhost","root","","event");
if(isset($_POST['signup'])){
	
	$email = $_POST['email'];
	$name = $_POST['name'];
	$pass = $_POST['pass'];
	$qstn = "hhgh1";
	
	$sql = mysqli_query($con,"insert into entry values('','$name','$email','$pass','$qstn')");
		echo "successfully signup";
		
	}
?>
<html>
<body>
<form  method="post" action="session.php">
<input type="text" name="email" placeholder="email"/>
<input type="password" name="pass" placeholder="password"/>
<input type="submit" name="login" value="login"/>
</form>
<br><br>
<form  method="post" action="index.php">
<input type="text" name="email" placeholder="email"/>
<input type="password" name="pass" placeholder="password"/>
<input type="text" name="name" placeholder="Name"/>
<input type="submit" name="signup" value="signup"/>
</form>
</body>
</html>