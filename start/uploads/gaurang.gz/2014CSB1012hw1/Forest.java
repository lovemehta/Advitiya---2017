import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Forest {

	private static final String TESTING_FILE = "ticdata2000.txt";
	int num_trees;
	int[][] matrix;
	DTree[] treeList;
	int attributes_to_each;
	
	int testLines;
	int[][] outputs;
	int[] actualOutput;
	
	public Forest(int n, int[][] m) throws FileNotFoundException {
		
		Scanner sc = new Scanner(new BufferedReader(new FileReader(TESTING_FILE)));
		this.testLines = Integer.parseInt(sc.nextLine());
		int testAttributes = Integer.parseInt(sc.nextLine());
		int testColumns = testAttributes+1;
		
		actualOutput = new int[testLines];
		
		System.out.println("TEST lines is "+testLines+", test att is "+testAttributes);
		int idx=0;
		int pos=0;
		while(sc.hasNextLine()) {
			String next_line = sc.nextLine();
			int label = Integer.parseInt(next_line.split("\t")[testColumns-1]);
			if(label==1)
				pos++;
			actualOutput[idx]=label;
			idx++;
		}
		
	//	System.out.println("pos is "+pos);
		sc.close();
		
		
		this.num_trees=n;
		this.matrix=m;
		treeList = new DTree[num_trees];
		outputs = new int[testLines][num_trees];		
		
		attributes_to_each=85;
		
		if(num_trees>10) {
			attributes_to_each = 9;
		}
		else {
			attributes_to_each = (matrix[0].length-1)/num_trees; //17 right now
		}
		
		System.out.println(num_trees+" trees constructed");
		System.out.println("Each tree has "+attributes_to_each+" attributes\n");
	}
	
	public void createForest() throws FileNotFoundException {
		
		int num_lines = matrix.length;
		int num_col = matrix[0].length;
		int attributes = num_col-1;
	
		for(int k=0;k<num_trees;k++) {
			
	//	for(int k=0;k<1;k++) {
			
			System.out.println("Making tree number "+(k+1));
			Node rootNode = new Node();
			
			ArrayList<Integer> a = new ArrayList<>(attributes);
			for (int i = 0; i < attributes; i++) {
			    a.add(i);
			}
			Collections.shuffle(a);
			
			ArrayList<Integer> b = new ArrayList<>(attributes_to_each);
			for(int i=0;i<attributes_to_each;i++) {
				b.add(a.get(i));
			}
			Collections.sort(b);
			
//			System.out.println(b.toString());
			
			for(int i=0;i<num_lines;i++) {
				
				StringBuilder sb = new StringBuilder();
				for(int j=0;j<attributes_to_each;j++) {
//					System.out.println("the random att is "+a.get(j));
					int abc = matrix[i][b.get(j)];
					sb.append(abc);
					sb.append("\t");
				}
				
	//			System.out.println("att to each is "+attributes_to_each);
				
				sb.append(matrix[i][num_col-1]);
				
				rootNode.instances.add(sb.toString());
		
			}		// instances have been put in root node
			
			int new_num_col = attributes_to_each+1;
			int posInst=0;
			for(String str:rootNode.instances) {
				int label = Integer.parseInt(str.split("\t")[new_num_col-1]);
				if(label==1)
					posInst++;
			}
			
			System.out.println("pos in Traning is "+posInst);
			
			rootNode.posLabel=posInst;
			rootNode.negLabel=(num_lines-posInst);
			
			DTree treeInForest = new DTree(rootNode,num_lines,new_num_col);
			
			rootNode.entropy = treeInForest.calcEntropy(posInst,(num_lines-posInst));

			treeInForest.createTree(rootNode);		// created tree		
			treeInForest.search4forest(outputs,k);
			
			System.out.println();
			
			treeList[k] = treeInForest;
		
		}			// end while
		
		
	}				//  end create forest
	
	public void checkAccuracy() throws FileNotFoundException {
			
		double correctMatch=0;
		for(int i=0;i<testLines;i++) {
			int avgAns=-1;
			int pos=0, neg=0;
			
			for(int k=0;k<num_trees;k++) {
				int ans=outputs[i][k];
				if(ans==1) {
					pos++;
				}
			}
			
			neg = num_trees-pos;
			if(neg>pos) {
				avgAns = 0;
			}
			else {
				avgAns = 1;
			}
			
			if(avgAns==actualOutput[i]) {
				correctMatch++;
			}
			
		}
		
		System.out.println(correctMatch+" correct matches !!!");
		
		double acc = (correctMatch*100)/testLines;
		acc = Double.parseDouble(new DecimalFormat("##.##").format(acc));
		System.out.println("Acc : "+acc +"%");
		
		
	}
	
}
