import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.Scanner;

public class q2 {

	private static final String TRAINING_FILE = "training.txt";

	public static void main(String[] args) throws UnsupportedEncodingException, FileNotFoundException {



		int ori_positive=0;
		Scanner sc = new Scanner(new BufferedReader(new FileReader(TRAINING_FILE)));
		int num_lines = Integer.parseInt(sc.nextLine());
		int attributes = Integer.parseInt(sc.nextLine());
		int num_col = attributes+1;

		Node ori_Node = new Node();

		while(sc.hasNextLine()) {
			String next_line = sc.nextLine();
			ori_Node.instances.add(next_line);
			int label = Integer.parseInt(next_line.split("\t")[num_col-1]);
			if(label==1) {
				ori_positive++;
			}
		}

		sc.close();

		double[] noises = {0,10,20,30,40,50};
		double[] accuracy = new double[noises.length];
		int idx=0;

		for(double noise:noises) {

			int pos_instances = ori_positive;
			Node rootNode = ori_Node;
			DTree noisyTree = new DTree(rootNode,num_lines,num_col);

			//Noise function //////*********************************

			System.out.println(noise+"% noise added in the data");
			for(int i=0;i<rootNode.instances.size();i++) {
				// Do some random shit
				String str = rootNode.instances.get(i);
				double random = Math.random()*100;
				if(random<noise) {
					if(str.split("\t")[num_col-1].equalsIgnoreCase("1")) {
						StringBuilder sb = new StringBuilder(str);
						sb.setCharAt(str.length()-1, '0');
						pos_instances--;
						rootNode.instances.set(i, sb.toString());
					}
					else {
						StringBuilder sb = new StringBuilder(str);
						sb.setCharAt(str.length()-1, '1');
						pos_instances++;
						rootNode.instances.set(i, sb.toString());
					}
				}
			}

			// end random /*/******************************************

			int totalInstances = num_lines;
			int trueInstances = pos_instances;
			int falseInstances = totalInstances - trueInstances;


			rootNode.entropy = noisyTree.calcEntropy(trueInstances, falseInstances);
			rootNode.posLabel = trueInstances;
			rootNode.negLabel = falseInstances;

			noisyTree.createTree(rootNode);


			/*ArrayList<Node> tempArrayList = new ArrayList<Node>();
		tempArrayList.add(rootNode);
		noisyTree.bfs(tempArrayList);*/

			accuracy[idx++]=noisyTree.search();
			Date date = new Date();
			System.out.println(date.toString());
			System.out.println();

		}
		
		System.out.println();
		String a="Noises", b="Accuracy";
		System.out.printf("%-10.30s  %-10.30s%n", a, b);
		for(int i=0;i<noises.length;i++) {
			System.out.printf("%-10.30s  %-10.30s%n", noises[i], accuracy[i]);
		}

	}

}
