import java.util.ArrayList;

class  Node {
	int data; // a node having specific value  
	int attributeIndex; // index of attribute varying from 0 to 84 value  
	double entropy;   
	int posLabel; // number of positive label instances in this node
	int negLabel; // number of -ve label instances in this node
	Node[] child;
	ArrayList<String> instances; // stores all instances and its attributes
	Node() {
		data = -1;
		attributeIndex = -1;
		posLabel = 0;
		negLabel = 0;
		entropy = -1;
		instances = new ArrayList<String>();
	}
}