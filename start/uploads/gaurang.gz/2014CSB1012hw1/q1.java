import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Scanner;


public class q1 {
	
	
	private static int totalInstancesTestFile = 0;
	private static final String TRAINING_FILE  = "training.txt"; // training data set
	private static String INPUT_FILE  = "ticdata2000.txt"; // test data set
	private static int maxLevel = 85; // used for early stopping on max height of tree
	private static int minInstancesInNode = 1; // used for early stopping  on min number of instances in a node
	private static int level = 0;
	private static ArrayList<Integer> attributeUsed = new ArrayList<Integer>(); // contains index of used 
	private static Node root = null; // root node of tree

	
	
	
	// Calculates entropy of a node given number of true instances and false instances
	public static double calcEntropy(int trueInst, int falseInst){
		if(trueInst ==0 && falseInst ==0) { // 0 number of instances
			return -1;
		}
		if(trueInst ==0 || falseInst ==0){ // pure node
			return 1;
		}
		double totalInst = trueInst + falseInst;
		double plusEnt = (-1)*(trueInst/totalInst)*(Math.log(trueInst/totalInst)/Math.log(2));
		double minusEnt = (-1)*(falseInst/totalInst)*(Math.log(falseInst/totalInst)/Math.log(2));
		return plusEnt+minusEnt;
	}
	
	// Calculates Information gain of a sub Tree given root node and its child Node
	public static double calcInfoGain(Node rootNode, Node childeNodes[]){
		double restEntropy = 0;
		for(int i=0;i < childeNodes.length;i++) {
			Node curNode = childeNodes[i];
			if(curNode.entropy != -1){
				restEntropy += (curNode.entropy*(curNode.posLabel + curNode.negLabel))/(rootNode.posLabel + rootNode.negLabel);
			}
		}
		return rootNode.entropy - restEntropy;
	}
		
	
	// attaches child nodes to the node 	
	public static void getChildNodes(Node node, int attributeIndex) {
		if(attributeIndex == 0) { // first attribute can have values from 1 -41
			node.child = new Node[42]; 
			for(int i=0;i<=41;i++)  {
				Node temp = new Node();
				temp.data = i;
				node.child[i] = temp;
			}
		} else { // all other attributes can have values ranging from 0 -10
			node.child =new Node[11];
			for(int i=0;i<=10;i++) {
				Node temp = new Node();
				temp.data = i;
				node.child[i] = temp;
			}
		}
	}
	
	
	// Create the tree recursively 
	public static void createTree(Node rootNode) throws FileNotFoundException {
		if(attributeUsed.size() >= 85 || rootNode.negLabel == 0 || rootNode.posLabel ==0) { // all attributes used or pure node
			return;
		}
		if(minInstancesInNode >= rootNode.posLabel + rootNode.negLabel){  // used as condition for early stopping
			return;
		}
		double maxInfoGain = -1;
		Node maxInfoGainRoot = null; 
		Node[] childNodes = null;
		for(int i=0;i < 85; i++) {
			getChildNodes(rootNode, i);  //has possible values attribute (using only posLable and negLabel)
			
			for(int k=0;k<rootNode.instances.size(); k++) { // calculte positive and negative labels
				String line = rootNode.instances.get(k);
//				System.out.println(line);
				int attributeVal = Integer.parseInt(line.split("\t")[i]);
				int label = Integer.parseInt(line.split("\t")[85]);

				Node curNode = rootNode.child[attributeVal];

				curNode.data = attributeVal;	
				curNode.instances.add(line); // adds instances to the node
				
				if(label == 1){ // positive label
					curNode.posLabel++;
				} else{
					curNode.negLabel++;
				}

			}
			for(int j =0;j <rootNode.child.length; j++) { // calcuates entropy of all child nodes				
				Node curNode = rootNode.child[j];
				curNode.entropy = calcEntropy(curNode.posLabel, curNode.negLabel);
			}

			double informationGain = calcInfoGain(rootNode, rootNode.child); // calculate information gain
			if(maxInfoGain < informationGain && attributeUsed.contains(i)== false) { // has maximum info gain and this attribute is not used till now in this path
				maxInfoGain = informationGain; // use this a max information gain
				rootNode.attributeIndex = i;
				maxInfoGainRoot = rootNode;
				childNodes = rootNode.child;  
			}
		}
		
		
		rootNode.child = childNodes;
		for(int i=0;i < rootNode.child.length; i++) {
			attributeUsed.add((Integer)rootNode.attributeIndex); // keeps track of attributes used in a path
			level++;
			if(level <= maxLevel) { // used as early stopping rule on max height of tree
				createTree(rootNode.child[i]);
			}
			level--;
			attributeUsed.remove((Integer)rootNode.attributeIndex);
		}
		
		
	}
	
	public static int attributes = 85; // total attributes
	
	
	// Breadth first search on the tree
	public static int bfs(ArrayList<Node> nodeArr, int num) {
		ArrayList<Node> temp = new ArrayList<Node>();
		int flag =0;
		for(int i=0;i <nodeArr.size(); i++) {
			Node childNode = nodeArr.get(i);
			if(childNode.attributeIndex == -1) {
				continue;
			}
			for(int j=0;j <childNode.child.length ;j++) {
				num++;
				Node node = childNode.child[j];
				if(node.attributeIndex == -1) {
					continue;
				}
				flag =1;
				temp.add(node);
//				System.out.print(node.attributeIndex+"\t");
			}
//			System.out.print(" +++ ");
		}
//		System.out.println();
		if(flag ==1)
			num = bfs(temp, num);
		return  num;
	}
	
	
	public static int levelDfs = 0;
	public static float accuracy = 0; // accuracy of the tree 

	//prunning the tree...  traversal using the DFS algorithm
	// given the root node
	// checkNow is used if we dont want to remove child nodes of that node e.g. for root node
	public static void pruningUsingDFS(Node node, Boolean checkNow) throws FileNotFoundException { 
		if(node.attributeIndex == -1) { // leaf node
			return;
		}

		if(checkNow.equals(true)) { 
			Node[] children = node.child; // copy of child ndoes
			getChildNodes(node, node.attributeIndex); // remove all child nodes 
			float newAcc = search(INPUT_FILE);  // checks accuracy on the input file i.e. test data sets
			if(newAcc > accuracy ) { // greater accuracy
				accuracy = newAcc;
				System.out.print("Accuracy increased to : "+ newAcc); 
				System.out.println(" ; Number of nodes changed to  : "+countNumberOfNodesInTree(root, 1));
			} else {
				node.child = children; // plug back the child nodes
			}
		}
		
		for(int i = 0; i< node.child.length ; i++) { // moving on to the child nodes for prunning
			levelDfs++;
			pruningUsingDFS(node.child[i], true);				
			levelDfs--;
		}
	}
	
	// counts the number of nodes in the tree including the child nodes 
	public static int countNumberOfNodesInTree(Node node,int num) throws FileNotFoundException { 
		if(node.attributeIndex == -1) { // leaf node
			return num;
		}
		
		for(int i = 0; i< node.child.length ; i++) { // count is using the bfs algo
			num = countNumberOfNodesInTree(node.child[i], num+1);				
		}
		return num;
	}
		
	// used to count the frequency of attributes used
	static int[] attributeFrequency = new int[85];
	
	// finds the accuracy of tree in the given file of instances 
	public static float search(String fileName) throws FileNotFoundException {
		Scanner sc = new Scanner(new BufferedReader(new FileReader(fileName)));

		int totalInstacesGiven =  Integer.parseInt(sc.nextLine());
		sc.nextLine();

		float incorrect =0;
		
		while(sc.hasNextLine()) {
			String line = sc.nextLine();
			int attributeVal[] = new int[86]; // puts all attributes and its label into a integer matrix
			String arr[] = line.split("\t");
			for(int i=0;i<arr.length; i++) {
				attributeVal[i] = Integer.parseInt(arr[i]);
			}
			
			Node node = root;
			int ans =0;
			Node prev = null; 
			while(true) {
				if(node.attributeIndex != -1) //not a leaf node
					attributeFrequency[node.attributeIndex]++;
				if(node.attributeIndex == -1) {		
					if(node.posLabel > node.negLabel) { // more positive label
						ans = 1;
					} else if(node.posLabel < node.negLabel) { // more negative labels
						ans = 0;
					}else if(node.posLabel == node.negLabel){ // equal number of labels on the node
						if(prev!= null && prev.posLabel <= prev.negLabel) { // check in the parent node
							ans = 0;
						} else {
							ans = 1;
						}
					}
					break;
				} else if(node.negLabel == 0) { // no negative labels
					ans = 1;
					break; 
				} else if(node.posLabel == 0) { // no positive labels
					ans = 0;
					break;
				}
				int index = node.attributeIndex;
				prev= node; // keeps track of parent of node
				node = node.child[attributeVal[index]]; // gets next child node
			}
			if(ans == attributeVal[85]) { // label matches with the actual ans
//				System.out.println("True");
			} else {
				incorrect++;
			}
		}
//		System.out.println(incorrect);
		float acc = ((totalInstacesGiven - incorrect)*100)/totalInstacesGiven; // finds accuracy
		sc.close();
		return acc;
	}
	
	
	public static void main(String[] args) throws UnsupportedEncodingException, FileNotFoundException {
//		INPUT_FILE = args[0];
//		Scanner sc =new Scanner(new BufferedReader(new FileReader(INPUT_FILE)));
//		PrintWriter printWriter = new PrintWriter("Training2.txt");
//		int ones = 60, zeroes = 940;
//		while(sc.hasNextLine()) {
//			String line = sc.nextLine();
//			int label = Integer.parseInt(line.split("\t")[85]);
//			if(label ==0 && zeroes >0 ) {
//				printWriter.println(line);
//				zeroes--;
//			} else if(label==1 && ones > 0 ) {
//				printWriter.println(line);
//				ones--;
//			}
//		}
//		printWriter.close();
//		sc.close();
		
//		findChildNodeValues();*/
		
		
		
		
		// Calculates total positive labels and negative labels in the training file
		Scanner sc = new Scanner(new BufferedReader(new FileReader(TRAINING_FILE)));
		int totalInstances = Integer.parseInt(sc.nextLine());
		int attributesTrainingSet = Integer.parseInt(sc.nextLine());
		int trueInstances = 0;
		while(sc.hasNextLine()) {
			String line = sc.nextLine();
			int label = Integer.parseInt(line.split("\t")[attributesTrainingSet]);
			if(label==1 ) {
				trueInstances++;
			}
			totalInstances++;
		}
		sc.close();
		
		// finds total instances and total attributes in the test file
		sc = new Scanner(new BufferedReader(new FileReader(INPUT_FILE)));
		totalInstancesTestFile = Integer.parseInt(sc.nextLine());
		int totalAttributesTestFile = Integer.parseInt(sc.nextLine());
		sc.close();
		
	
		
		int falseInstances = totalInstances - trueInstances;
		Node rootNode = new Node();
		rootNode.entropy = calcEntropy(trueInstances, falseInstances);
		rootNode.posLabel = trueInstances;
		rootNode.negLabel = falseInstances;
		sc = new Scanner(new BufferedReader(new FileReader(TRAINING_FILE)));
		sc.nextLine();// total instacnes
		sc.nextLine(); //total attributes 
		while(sc.hasNextLine()) {
			rootNode.instances.add(sc.nextLine());
		}
		root = rootNode;
		sc.close();
		createTree(rootNode);
		System.out.println("Index\tFrequency");
		search(INPUT_FILE); // calculates the actual accuracy
		for (int i = 0; i < attributeFrequency.length; i++) {
			System.out.println(i + "\t"+ attributeFrequency[i]);
		}
	}

}
