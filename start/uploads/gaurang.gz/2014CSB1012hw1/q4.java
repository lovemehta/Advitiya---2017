import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class q4 {

	public static void main(String[] args) throws FileNotFoundException {

		Scanner sc = new Scanner(new BufferedReader(new FileReader("training.txt")));
		int num_lines = Integer.parseInt(sc.nextLine());
		int attributes = Integer.parseInt(sc.nextLine());
		int num_col = attributes+1;

		int num_trees=8;
		
		int[][] matrix = new int[num_lines][num_col];	// all details in this
		
		System.out.println("TRAINING num lines is "+num_lines+", num col is "+num_col);
		
		int lineCount = 0;
		while (sc.hasNextLine()) {
			String nextLine = sc.nextLine();
		    String[] numbers = nextLine.split("\t");
		    for ( int i = 0 ; i < num_col ; i++) 
		         matrix[lineCount][i] = Integer.parseInt(numbers[i]);

		    lineCount++;
		}
		
		sc.close();

		// matrix has been created
		
		Forest f1 = new Forest(num_trees, matrix);
		f1.createForest();
		f1.checkAccuracy();
	}
	
}