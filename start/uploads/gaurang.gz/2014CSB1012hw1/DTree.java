import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Scanner;


public class DTree {
	
	Node root;
	int num_cols;
	int num_lines;
	
	public DTree(Node r, int numLine, int numCol) {
		this.root = r;
		this.num_lines=numLine;
		this.num_cols=numCol;
	}
	
	static ArrayList<Integer> attributeUsed = new ArrayList<Integer>(); // contains index of used
	
	public static final String TRAINING_FILE  = "training.txt";
	public static final String SAMPLE_FILE  = "small.txt";
	public static final String TESTING_FILE  = "ticdata2000.txt";
	
	public double calcEntropy(int trueInst, int falseInst){
		if(trueInst ==0 && falseInst ==0) {
			return -1;
		}
		if(trueInst ==0 || falseInst ==0){
			return 1;
		}
		
		double totalInst = trueInst + falseInst;
		double plusEnt = (-1)*(trueInst/totalInst)*(Math.log(trueInst/totalInst)/Math.log(2));
		double minusEnt = (-1)*(falseInst/totalInst)*(Math.log(falseInst/totalInst)/Math.log(2));
		return plusEnt+minusEnt;
	}
	
	
	public double calcInfoGain(Node rootNode, Node childeNodes[]){
		
		double restEntropy = 0;
		for(int i=0;i < childeNodes.length;i++) {
			Node curNode = childeNodes[i];
			if(curNode.entropy != -1){
				restEntropy += (curNode.entropy*(curNode.posLabel + curNode.negLabel))/(rootNode.posLabel + rootNode.negLabel);
			}
		}
		return rootNode.entropy - restEntropy;
	}
	
	public void getChildNodes(Node node, int attributeIndex) {
		if(attributeIndex == 0) {
			node.child = new Node[42];
			for(int i=0;i<=41;i++)  {
				Node temp = new Node();
				temp.data = i;
				node.child[i] = temp;
			}
		} else {
			node.child =new Node[11];
			for(int i=0;i<=10;i++) {
				Node temp = new Node();
				temp.data = i;
				node.child[i] = temp;
			}
		}
	}
	
	
	public void createTree(Node rootNode) {

	/*	System.out.println("num cols "+num_cols);
		System.out.println("neg label is "+rootNode.negLabel);
		System.out.println("pos label is "+rootNode.posLabel);
		System.out.println("att used sze is "+attributeUsed.size());
	*/	
		if(attributeUsed.size() >= (num_cols-1) || rootNode.negLabel == 0 || rootNode.posLabel == 0) {
			return;
		}
		
//		System.out.println("inside create");
		
		double maxInfoGain = -1;
		
		@SuppressWarnings("unused")
		Node maxInfoGainRoot = null; 
		Node[] childNodes = null;
		
		for(int i=0;i < (num_cols-1); i++) {
			
	//		System.out.println("inside loop, i is "+i);
			getChildNodes(rootNode, i);  //has possible values attribute (using only posLable and negLabel)

	//		System.out.println("root instances size is "+rootNode.instances.size());
			
			for(int k=0;k<rootNode.instances.size(); k++) { // calculte pos ,neg label
				
				String line = rootNode.instances.get(k);
				int attributeVal = Integer.parseInt(line.split("\t")[i]);
				int label = Integer.parseInt(line.split("\t")[num_cols-1]);
				
		/*		System.out.println("Att val is "+attributeVal);
				System.out.println("label is "+label);
		*/		
				Node curNode = rootNode.child[attributeVal];

				curNode.data = attributeVal;	
				curNode.instances.add(line);
				
				if(label == 1){
					curNode.posLabel++;
				} else{
					curNode.negLabel++;
				}

			}
			
			for(int j =0; j<rootNode.child.length; j++) {
				
	//			System.out.println("inside jJJJJjjjJJJJJjjjjJJJJ");
				Node curNode = rootNode.child[j];
				curNode.entropy = calcEntropy(curNode.posLabel, curNode.negLabel);
			}
			
			double informationGain = calcInfoGain(rootNode, rootNode.child);
	//		System.out.println("info gain is "+informationGain);
			
			if(maxInfoGain < informationGain && attributeUsed.contains(i)== false) {
	//			System.out.println("Inside if !!!");
				maxInfoGain = informationGain;
				rootNode.attributeIndex = i;
				maxInfoGainRoot = rootNode;
				childNodes = rootNode.child;
			}
		}
		
		rootNode.child = childNodes;
		
//		System.out.println("root node child length is "+rootNode.child.length);
		
		for(int i=0;i < rootNode.child.length; i++) {
			attributeUsed.add((Integer)rootNode.attributeIndex);
			createTree(rootNode.child[i]);
			attributeUsed.remove((Integer)rootNode.attributeIndex);
		}
		
	}		// end create tree
	
	public double search() throws FileNotFoundException {

		Scanner sc = new Scanner(new BufferedReader(new FileReader(TESTING_FILE)));
		float incorrect = 0;
		int lines = Integer.parseInt(sc.nextLine());
		int attributes = Integer.parseInt(sc.nextLine());
		int columns = attributes+1;
		
//		System.out.println("TESTING lines is "+lines+" and cols is "+columns);
		while(sc.hasNextLine()) {
			String line = sc.nextLine();
			int attributeVal[] = new int[columns];
			String arr[] = line.split("\t");
			
			for(int i=0;i<arr.length; i++) {
				attributeVal[i] = Integer.parseInt(arr[i]);
			}

			Node node = root;
			int ans =0;
			Node prev = null; 
			while(true) {
				if(node.attributeIndex == -1) {
					if(node.posLabel > node.negLabel) {
						ans = 1;
					} else if(node.posLabel < node.negLabel) {
						ans = 0;
					}else if(node.posLabel == node.negLabel){
						if(prev!= null && prev.posLabel <= prev.negLabel) {
							ans = 0;
						} else {
							ans = 1;
						}
					}
					break;
				}

				else if(node.negLabel == 0) {
					ans = 1;
					break;
				}

				else if(node.posLabel == 0) {
					ans = 0;
					break;
				}

				int index = node.attributeIndex;
				prev = node;
				node = node.child[attributeVal[index]];
			}

			if(ans != attributeVal[columns-1]) {
				incorrect++;
			}
		}

		System.out.println(incorrect+" incorrect values");
		double acc = ((lines - incorrect)*100)/lines;
		acc = Double.parseDouble(new DecimalFormat("##.##").format(acc));
		System.out.println("Acc : "+acc +"%");
		sc.close();
		
		return acc;
		
	}				// end search
	
	// ********************************
	
	public void search4forest(int[][] outputs, int col) throws FileNotFoundException {

		Scanner sc = new Scanner(new BufferedReader(new FileReader(TESTING_FILE)));
		float incorrect = 0;
		int lines = Integer.parseInt(sc.nextLine());
		int attributes = Integer.parseInt(sc.nextLine());
		int columns = attributes+1;
		
//		int[] treeOutput = new int[lines];
		
//		System.out.println("TESTING lines is "+lines+" and cols is "+columns);
		int lineIdx=0;
		while(sc.hasNextLine()) {
			String line = sc.nextLine();
			int attributeVal[] = new int[columns];
			String arr[] = line.split("\t");
			
			for(int i=0;i<arr.length; i++) {
				attributeVal[i] = Integer.parseInt(arr[i]);
			}

			Node node = root;
			int ans=0;
			Node prev = null; 
			while(true) {
				if(node.attributeIndex == -1) {
					if(node.posLabel > node.negLabel) {
						ans = 1;
					} else if(node.posLabel < node.negLabel) {
						ans = 0;
					}else if(node.posLabel == node.negLabel){
						if(prev!= null && prev.posLabel <= prev.negLabel) {
							ans = 0;
						} else {
							ans = 1;
						}
					}
					break;
				}

				else if(node.negLabel == 0) {
					ans = 1;
					break;
				}

				else if(node.posLabel == 0) {
					ans = 0;
					break;
				}

				int index = node.attributeIndex;
				prev = node;
				node = node.child[attributeVal[index]];
			}			// end while

	//		System.out.println("ans is "+ans);
			outputs[lineIdx][col]=ans;
			
	//		treeOutput[lineIdx] = attributeVal[columns-1];
			lineIdx++;
			
			if(ans != attributeVal[columns-1]) {
				incorrect++;
			}
		}				// end while

		System.out.println(incorrect+" incorrect values");
		double acc = ((lines - incorrect)*100)/lines;
		acc = Double.parseDouble(new DecimalFormat("##.##").format(acc));
		System.out.println("Acc : "+acc +"%");
		sc.close();
		
//		return treeOutput;
//		return acc;
		
	}				// end search
	
	
	
	
	public void bfs(ArrayList<Node> nodeArr) {
		ArrayList<Node> temp = new ArrayList<Node>();
		int flag =0;
		for(int i=0;i <nodeArr.size(); i++) {
			Node childNode = nodeArr.get(i);
			if(childNode.attributeIndex == -1) {
				continue;
			}
			for(int j=0;j <childNode.child.length ;j++) {
				Node node = childNode.child[j];
				if(node.attributeIndex == -1) {
					continue;
				}
				flag =1;
				temp.add(node);
				System.out.print(node.attributeIndex+"\t");
			}
			System.out.print(" +++ ");
		}
		System.out.println();
		if(flag ==1)
			bfs(temp);
	
	}
	
	
	public static int level = 0;
	public void dfs(Node node) {
		if(node.attributeIndex == -1) {
			return;
		}
		System.out.println("Attribute Index"+node.attributeIndex+ "  level "+ level); 
		for(int i = 0; i< node.child.length ; i++) {
			level++;
			dfs(node.child[i]);
			level--;
		}
	}

}
